package com.demo.ersSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErsSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErsSpringApplication.class, args);
		
		
		
	}

}
